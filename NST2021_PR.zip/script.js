// Przemysław Reducha
// Zad. 1

const fizzBuzz = () => {
    let arr = [];
    let current;

    for (let i = 1; i <= 100; i++) {
        if (i % 6 === 0) {
            arr.push('FizBuz');
        } else if (i % 2 === 0) {
            arr.push('Fiz');
        } else if (i % 3 === 0) {
            arr.push('Buz')
        } else {
            arr.push(i);
        }
    }

    console.log(arr.join(', '));
}

// fizzBuzz();

// Zad. 2
const userCircle = () => {
    let input = window.prompt('Podaj promien okregu');
    const area = (Math.PI * input ** 2).toFixed(2);
    const perimeter = (2 * Math.PI * input).toFixed(2);
    
    console.log({ area, perimeter })
}

// userCircle();

// Zad. 3
const arraySum = () => {
    let arr = [];
    let sum = 0;

    for (let i = 0; sum <= 200; i++) {
        let element = Math.round(Math.random() * (10 - 1) + 1);
        sum += element;
        arr.push(element);
    }

    console.log(arr);

    const minValue = Math.min(...arr);
    const maxValue = Math.max(...arr);

    console.log({ minValue, maxValue });

    arr.splice(arr.indexOf(minValue), 1);
    arr.splice(arr.lastIndexOf(maxValue), 1);

    const minCount = arr.filter((element) => element === minValue).length;
    const maxCount = arr.filter((element) => element === maxValue).length;

    console.log({ minCount, maxCount })

    let uniqueValues = [...new Set(arr)];
    

    let arrayToBeMoved = [...arr];

    for (let i = 0; i < 10; i++) {
        const element = arrayToBeMoved.shift()
        arrayToBeMoved.push(element);
    }

    console.log({ arrayAfterMoving: arrayToBeMoved});
}

// arraySum();

// Zad. 4
const namesReplace = () => {
    let namesArr = ['Adam', 'Tomek', 'Przemek', 'Krystian', 'Karol'];
    const regexForA = /a|A/gm;

    namesArr.forEach((name) => name.replace(regexForA, '4'));

    console.log(namesArr.join(', '))
}

namesReplace();